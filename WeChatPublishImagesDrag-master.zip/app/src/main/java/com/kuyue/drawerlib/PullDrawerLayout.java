package com.kuyue.drawerlib;

import android.content.Context;
import android.util.AttributeSet;

import com.kuyue.wechatpublishimagesdrag.R;


/**
 * Created by WangYao on 2019/5/16.
 */

public class PullDrawerLayout extends BaseDragLayout {

    public PullDrawerLayout(Context context) {
        super(context);
    }

    public PullDrawerLayout(Context context, AttributeSet attrs) {
        super(context, attrs, 0);
    }

    public PullDrawerLayout(Context context, AttributeSet attrs, int defStyle) {
        super(context, attrs, defStyle);
    }


    @Override
    public void onViewStatus(boolean isOpen) {

    }

    @Override
    public void onViewOffset(float mOffset) {

    }

    @Override
    public void initView() {
        setContentView(findViewById(R.id.drag_layout));
    }
}
