package com.kuyue.wechatpublishimagesdrag;

import android.support.v7.widget.RecyclerView;
import android.view.View;

public class SecondViewHolder extends RecyclerView.ViewHolder {

        public SecondViewHolder(View itemView) {
            super(itemView);
        }
    }