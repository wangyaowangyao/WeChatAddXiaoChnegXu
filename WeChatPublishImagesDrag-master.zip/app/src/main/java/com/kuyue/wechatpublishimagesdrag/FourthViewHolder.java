package com.kuyue.wechatpublishimagesdrag;

import android.support.v7.widget.RecyclerView;
import android.view.View;

public class FourthViewHolder extends RecyclerView.ViewHolder {

        public FourthViewHolder(View itemView) {
            super(itemView);
        }
    }