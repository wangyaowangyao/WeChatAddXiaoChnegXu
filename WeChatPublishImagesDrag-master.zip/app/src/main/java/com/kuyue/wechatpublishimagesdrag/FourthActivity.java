package com.kuyue.wechatpublishimagesdrag;

import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;

import java.io.File;
import java.io.FileOutputStream;
import java.text.DateFormat;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created by WangYao on 2019/5/30.
 */

public class FourthActivity extends AppCompatActivity {
    List<String> stringList = new ArrayList<>();
    DecimalFormat decimalFormat = null;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        decimalFormat = new DecimalFormat("0.00");
        new Thread(new Runnable() {
            @Override
            public void run() {
                getStingList();
                String string=WriteStringToFile();
                saveFile("dimens.xml",string);
                Log.e("FourthActivity", "文件写入结束");
            }
        }).start();
    }

    public void getStingList() {
        for (int i = 1; i < 2049; i++) {
            String dp_text = "dp_" + i;
            float value = (float) (i / 4.0);
            String dp_value = decimalFormat.format(value) + "dp";
            String finalStr = "<dimen name=\"" + dp_text + "\">" + dp_value + "</dimen>";
            stringList.add(finalStr);
            Log.e("FourthActivity", finalStr);
        }

    }

    public String WriteStringToFile() {
        StringBuilder stringBuilder = new StringBuilder();
        for (int i = 0; i < stringList.size(); i++) {

                stringBuilder.append(stringList.get(i) + "\r");

        }
        return stringBuilder.toString();
    }

    DateFormat formatter = new SimpleDateFormat("yyyy-MM-dd-HH-mm-ss");

    public void saveFile(String fileName, String fileBody) {
        String time = formatter.format(new Date());
        /***
         * 带上时间会在本地存储太多的文件（开发调试的时候可以用这个）
         *  String newfileName = time + "-" + fileName;
         */
        String newfileName = fileName;
        if (Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED)) {
            String path = Environment.getExternalStorageDirectory().getPath() + "/wangyao/";
            File dir = new File(path);
            if (!dir.exists()) {
                dir.mkdirs();
            }
            try {
                FileOutputStream fos = new FileOutputStream(path + newfileName);
                fos.write(fileBody.toString().getBytes());
                fos.close();
            } catch (Exception e) {

            }
        }
    }
}
