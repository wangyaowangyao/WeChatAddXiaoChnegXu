package com.kuyue.wechatpublishimagesdrag;

public class ContentBean {
        String name;

        public ContentBean(String name) {
            this.name = name;
        }
    }