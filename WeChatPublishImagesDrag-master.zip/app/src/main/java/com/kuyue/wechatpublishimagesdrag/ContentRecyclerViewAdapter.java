package com.kuyue.wechatpublishimagesdrag;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;

import java.util.List;

public class ContentRecyclerViewAdapter extends RecyclerView.Adapter {
    List<Object> datas;

    public ContentRecyclerViewAdapter(List<Object> datas) {
        this.datas = datas;
    }

    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        int bottom_text_height = getItemBottomTextHeight();
        int item_width = getItemWidth2();
        RelativeLayout.LayoutParams layoutParams = null;
        RecyclerView.ViewHolder viewHolder = null;
        ImageView imageView = null;
        View view = null;
        switch (viewType) {
            case 1:
                view = layoutInflater.inflate(R.layout.first_item_layout, parent, false);
                viewHolder = new FirstViewHolder(view);
                break;
            case 2:
                view = View.inflate(MyApplication.getInstance().getContext(), R.layout.five_item_layout, null);
                imageView = view.findViewById(R.id.image);
                imageView.setLayoutParams(new LinearLayout.LayoutParams(getImageWidth(), getImageWidth()));
                layoutParams = new RelativeLayout.LayoutParams(item_width, getImageWidth() + bottom_text_height);
                view.setLayoutParams(layoutParams);
                viewHolder = new FirstViewHolder(view);
                break;
            case 3:
                view = View.inflate(MyApplication.getInstance().getContext(), R.layout.fourth_item_layout, null);
                imageView = view.findViewById(R.id.image);
                imageView.setLayoutParams(new LinearLayout.LayoutParams(getImageWidth(), getImageWidth()));
                layoutParams = new RelativeLayout.LayoutParams(item_width, getImageWidth() + bottom_text_height);
                view.setLayoutParams(layoutParams);
                viewHolder = new FirstViewHolder(view);
                break;
            case 4:
                view = View.inflate(MyApplication.getInstance().getContext(), R.layout.second_item_layout, null);
                imageView = view.findViewById(R.id.image);
                imageView.setLayoutParams(new LinearLayout.LayoutParams(getImageWidth(), getImageWidth()));
                layoutParams = new RelativeLayout.LayoutParams(item_width, getImageWidth() + bottom_text_height);
                view.setLayoutParams(layoutParams);
                viewHolder = new FirstViewHolder(view);
                break;
            case 5:
                view = layoutInflater.inflate(R.layout.third_item_layout, parent, false);
                viewHolder = new FirstViewHolder(view);
                break;

        }
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        if (position > 0 && position < 9) {
            holder.itemView.setVisibility(View.GONE);
        }
    }

    @Override
    public int getItemCount() {
        if (datas != null) {
            return datas.size();
        }
        return 0;
    }

    @Override
    public int getItemViewType(int position) {
        if (position == 0) {
            return 1;

        } else if (position == 1) {
            return 2;

        } else if (position == 2) {
            return 3;

        } else if (position == 3) {
            return 3;

        } else if (position == 4) {
            return 4;

        } else if (position == 5) {
            return 2;

        } else if (position == 6) {
            return 3;

        } else if (position == 7) {
            return 3;

        } else if (position == 8) {
            return 4;

        } else if (position == 9) {
            return 5;

        } else if (position == 10) {
            return 2;

        } else if (position == 11) {
            return 3;

        } else if (position == 12) {
            return 3;

        } else if (position == 13) {
            return 4;

        } else if (position == 14) {
            return 2;

        } else if (position == 15) {
            return 3;

        } else if (position == 16) {
            return 3;

        } else if (position == 17) {
            return 4;

        } else if (position == 18) {
            return 2;

        } else if (position == 19) {
            return 3;

        } else if (position == 20) {
            return 3;

        } else if (position == 21) {
            return 4;

        } else if (position == 22) {
            return 2;

        } else if (position == 23) {
            return 3;

        } else if (position == 24) {
            return 3;

        } else if (position == 25) {
            return 4;

        } else {
            return 6;
        }

    }


    public int getWidthPX() {
        WindowManager wm = (WindowManager) MyApplication.getInstance().getContext().getSystemService(Context.WINDOW_SERVICE);
        DisplayMetrics dm = new DisplayMetrics();
        wm.getDefaultDisplay().getMetrics(dm);
        return dm.widthPixels;
    }

    public float getSpace() {
        float space = MyApplication.getInstance().getContext().getResources().getDimension(R.dimen.dp_30);

        return space;
    }

    public int getItemWidth2() {
        float screen_width = MyApplication.getInstance().getContext().getResources().getDisplayMetrics().widthPixels - getSpace();

        return (int) (screen_width / 4);
    }

    public int getItemBottomTextHeight() {
        float bottom_text_height = MyApplication.getInstance().getContext().getResources().getDimension(R.dimen.dp_111);

        return (int) bottom_text_height;
    }

    public int getImageWidth() {
        float space = MyApplication.getInstance().getContext().getResources().getDimension(R.dimen.dp_120);

        return (int) space;
    }
}