package com.kuyue.wechatpublishimagesdrag;

import android.support.v7.widget.RecyclerView;
import android.view.View;

public class FirstViewHolder extends RecyclerView.ViewHolder {

        public FirstViewHolder(View itemView) {
            super(itemView);
        }
    }