package com.kuyue.wechatpublishimagesdrag;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.helper.ItemTouchHelper;
import android.util.Log;
import android.view.DragEvent;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by WangYao on 2019/5/29.
 */

public class ThreeActivity extends AppCompatActivity {
    String TAG = "ThreeActivity";
    RecyclerView content_recycler_view;
    TextView bottom_hint_text;
    List<Object> objectList = null;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.three_activity);
        content_recycler_view = findViewById(R.id.content_recycler_view);
        bottom_hint_text = findViewById(R.id.bottom_hint_text);
        objectList = getData();
        Log.e(TAG, objectList.size() + "");
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 4);
        gridLayoutManager.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
            @Override
            public int getSpanSize(int position) {
                if (position == 0) {
                    return 4;
                } else if (position == 9) {
                    return 4;

                } else {
                    return 1;
                }
            }
        });
        final int space = (int) (getResources().getDimension(R.dimen.dp_80));
        content_recycler_view.setLayoutManager(gridLayoutManager);
        ContentRecyclerViewAdapter contentRecyclerViewAdapter = new ContentRecyclerViewAdapter(objectList);
        content_recycler_view.setAdapter(contentRecyclerViewAdapter);
        ContentRecyclerViewCallBack contentRecyclerViewCallBack = new ContentRecyclerViewCallBack(contentRecyclerViewAdapter, objectList);
        final ItemTouchHelper itemTouchHelper = new ItemTouchHelper(contentRecyclerViewCallBack);
        bottom_hint_text.setOnDragListener(new View.OnDragListener() {
            @Override
            public boolean onDrag(View v, DragEvent event) {
                return true;
            }
        });
        itemTouchHelper.attachToRecyclerView(content_recycler_view);
        content_recycler_view.addOnItemTouchListener(new OnRecyclerItemClickListener(content_recycler_view) {

            @Override
            public void onItemClick(RecyclerView.ViewHolder vh) {

            }

            @Override
            public void onItemLongClick(RecyclerView.ViewHolder vh) {
                //如果item不是第一个，则执行拖拽
                itemTouchHelper.startDrag(vh);

            }
        });
        contentRecyclerViewCallBack.setDragListener(new ContentRecyclerViewCallBack.DragListener() {
            @Override
            public void deleteState(boolean delete) {
                if (delete) {
                    bottom_hint_text.setBackgroundResource(R.color.holo_red_dark);
                    bottom_hint_text.setText(getResources().getString(R.string.post_delete_tv_s));
                } else {
                    bottom_hint_text.setText(getResources().getString(R.string.post_delete_tv_d));
                    bottom_hint_text.setBackgroundResource(R.color.holo_red_light);
                }
            }

            @Override
            public void dragState(boolean start) {
                if (start) {
                    bottom_hint_text.setVisibility(View.VISIBLE);
                } else {
                    bottom_hint_text.setVisibility(View.GONE);
                }
            }

            @Override
            public void clearView() {

            }
        });

    }

    @NonNull
    private List<Object> getData() {
        final List<Object> objectList = new ArrayList<>();
        for (int i = 0; i < 26; i++) {
            objectList.add(new ContentBean(i + ""));
        }
        return objectList;
    }

}
