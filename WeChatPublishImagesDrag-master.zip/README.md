# WeChatPublishImagesDrag
仿微信发布图片拖拽和删除功能
demo相关博客地址：http://blog.csdn.net/u013231041/article/details/75062688
